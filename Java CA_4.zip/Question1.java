import java.util.Scanner;

public class Question1 {

	public static void main(String[] args) {
		
		String sentence = "";
		int counter = 0;
		String[] words;
		
		Scanner reader = new Scanner(System.in);
		
		// Part 1 : do while loop
		do
		{
			System.out.print("Please enter a sentence: ");
			sentence = reader.nextLine();
			
			
			if(sentence.length() > 15)
			{
				System.out.println("Greater than 15 characters. End of loop\n");
			}
			
		}
		while(sentence.length() < 16);
		
		// Part 2 : print out each word in the sentence
		words = sentence.split(" ");
		System.out.println("SENTENCE WORD BREAKDOWN\n-----------------");
		
		
		for(counter = 0; counter < words.length; counter++)
		{	
			System.out.println("Word " + (counter) +  " " + words[counter]);
		   counter++;
		}
		
		
	}

}
