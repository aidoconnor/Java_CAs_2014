import javax.swing.JOptionPane;

public class Question2 {

	public static void main(String[] args) {
		String userInput = "";
		int result = 1;
		String output = "";
				
		userInput = JOptionPane.showInputDialog(null, "Please enter the factorial number", "Input", JOptionPane.PLAIN_MESSAGE);
		
		int factorial = Integer.parseInt(userInput);
		
		while(factorial > 0)
		{
			result *= factorial;
			output += factorial + " X ";
			factorial--;
		}
		
		JOptionPane.showMessageDialog(null, userInput + "! = " + output + " = " + result, "output", JOptionPane.PLAIN_MESSAGE);

	}

}
